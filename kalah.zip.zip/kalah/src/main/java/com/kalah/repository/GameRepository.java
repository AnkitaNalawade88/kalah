package com.kalah.repository;

import com.kalah.domain.Game;
import org.springframework.data.repository.CrudRepository;


public interface GameRepository extends CrudRepository<Game, Integer> { }
