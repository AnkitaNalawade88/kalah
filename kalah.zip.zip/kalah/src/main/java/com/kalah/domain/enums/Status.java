package com.kalah.domain.enums;

public enum Status {

    IN_PROGRESS, FIRST_PLAYER_WIN, SECOND_PLAYER_WIN, DRAW
}
