package com.kalah.exception;

public class IllegalPitNumberException extends RuntimeException {

    public IllegalPitNumberException(String message) {
        super(message);
    }
}
