package com.kalah.exception;

import com.kalah.domain.enums.Status;

public class GameTerminatedException extends RuntimeException {

    private final Status status;

    public GameTerminatedException(String message, Status status) {
        super(message);
        this.status = status;
    }

    public Status getStatus() {
        return status;
    }
}
